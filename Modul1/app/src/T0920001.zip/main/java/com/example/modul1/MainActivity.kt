package com.example.modul1

import android.content.Context
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Paint
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.Surface
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.roundToInt
import android.view.View
import android.widget.FrameLayout
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    private lateinit var listView: ListView
    private lateinit var addButton: Button
    private lateinit var adapter: CustomAdapter
    private lateinit var itemView: View


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        listView = findViewById(R.id.listView)
        addButton = findViewById(R.id.addButton)
        adapter = CustomAdapter()
        listView.adapter = adapter
        addButton.setOnClickListener {
            adapter.addItem(datas(0))
            adapter.notifyDataSetChanged()
        }
    }

    private inner class CustomAdapter : BaseAdapter() {

        private val data: MutableList<datas> = mutableListOf()

        override fun getCount(): Int = data.size

        override fun getItem(position: Int): Any = data[position]

        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            var view: View? = convertView
            var viewHolder: ViewHolder
            if(view == null){
                itemView = layoutInflater.inflate(R.layout.item, parent, false)
                view = itemView
                viewHolder = ViewHolder()
                view.tag = viewHolder
            }
            else{
                viewHolder = view.tag as ViewHolder
            }
            viewHolder.updateView(data[position])
            return view
        }

        fun addItem(item: datas) {
            data.add(item)
        }
        inner class ViewHolder{
            val textViewLeft = itemView.findViewById<TextView>(R.id.textView)
            val buttonStart = itemView.findViewById<Button>(R.id.startButton)

            fun updateView(data: datas){
                buttonStart.setOnClickListener {
                    Log.d("Thread",count.toString())
                    if (buttonStart.text == "START") {
                        buttonStart.text = "STOP"
                            Thread {
                                for (count in 1..10) {
                                    runOnUiThread {
                                        data.count = count
                                        notifyDataSetChanged()
                                        textViewLeft.text = count.toString()
                                    }
                                    try {
                                        Thread.sleep(1000)
                                    } catch (e: InterruptedException) {
                                    }
                                }
                            }.start()
                        }
                    else{
                        buttonStart.text = "START"
                    }
                    }
                }
            }
        }

}
package com.example.modul1

data class datas(var count: Int)

package com.example.modul1

import android.util.Log
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class APIAccess{
    fun connect(requestURL: URL): String{
        val conn = requestURL.openConnection()as HttpURLConnection
        conn.connect()
        val responseCode = conn.responseCode
        Log.d("response",responseCode.toString() + "")
        val responseStream = conn.inputStream
        val result = convertIsToString(responseStream)
        responseStream?.close()
        conn.disconnect()
        return result
    }

    private fun convertIsToString(stream: InputStream?): String{
        val builder = StringBuilder()
        val reader = BufferedReader(InputStreamReader(stream))
        var line: String?
        while(reader.readLine().also {line = it} != null){
            builder.append(line)
        }
        reader.close()
        return builder.toString()
    }
}
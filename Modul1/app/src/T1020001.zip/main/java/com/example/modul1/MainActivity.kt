package com.example.modul1
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var expressionEditText: EditText
    private lateinit var precisionEditText: EditText
    private lateinit var resultTextView: TextView

    private val mathApiService = MathApiService("your_base_url")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        expressionEditText = findViewById(R.id.expression)
        precisionEditText = findViewById(R.id.precision)
        resultTextView = findViewById(R.id.result)

        val buttonHitungGET: Button = findViewById(R.id.buttonHitungGET)
        val buttonHitungPOST: Button = findViewById(R.id.buttonHitungPOST)

        buttonHitungGET.setOnClickListener {
            val expression = expressionEditText.text.toString()
            val precision = precisionEditText.text.toString().toIntOrNull() ?: 0
            performGetRequest(expression, precision)
        }

        buttonHitungPOST.setOnClickListener {
            val expression = expressionEditText.text.toString()
            val precision = precisionEditText.text.toString().toIntOrNull() ?: 0
            performPostRequest(expression, precision)
        }
    }

    private fun performGetRequest(expression: String, precision: Int) {
    }

    private fun performPostRequest(expression: String, precision: Int) {
    }

    private fun updateResult(result: String) {
        resultTextView.text = result
    }
}
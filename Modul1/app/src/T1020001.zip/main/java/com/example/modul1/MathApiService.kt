package com.example.modul1

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL

class MathApiService(private val baseUrl: String) {

    private val apiAccess = APIAccess()

    fun performGetRequest(expression: String, precision: Int, callback: (String) -> Unit) {
        GlobalScope.launch {
            val url = createGetUrl(expression, precision)
            val result = apiAccess.connect(url)
            withContext(Dispatchers.Main) {
                callback(result)
            }
        }
    }

    fun performPostRequest(expression: String, precision: Int, callback: (String) -> Unit) {
        GlobalScope.launch {
            val url = createPostUrl()
            val postData = createPostData(expression, precision)
            val result = apiAccess.connect(url, "POST", postData)
            withContext(Dispatchers.Main) {
                callback(result)
            }
        }
    }
    private fun createGetUrl(expression: String, precision: Int): URL {
        // TODO: Create URL for GET request
    }

    private fun createPostUrl(): URL {
        // TODO: Create URL for POST request
    }

    private fun createPostData(expression: String, precision: Int): String {
        // TODO: Create POST data
    }
}
